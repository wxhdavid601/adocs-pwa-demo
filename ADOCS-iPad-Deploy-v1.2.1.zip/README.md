# ADOCS Render 静态部署版 v1.2.1

**公开演示站点，不是航空运行指挥系统，不包含用户上传的原始机场图。**

## 部署到 Render

1. 创建一个 GitHub 仓库并上传本仓库全部文件（保留 `public/` 目录）。
2. Render → New → Static Site → 选择该 GitHub 仓库，branch 为 `main`。
3. Name: `adocs-pwa-demo`（若同名则调整），Build Command: `echo "ADOCS static PWA assets ready"`，Publish Directory: `public`。
4. 完成首次 Deploy 后，使用 Render 提供的 `https://...onrender.com` 访问。
5. iPad Safari 打开 HTTPS 网址，点击 ADOCS 的“安装到设备”/“检验离线资源与本地存储”；显示离线已就绪后，在分享菜单点击“添加到主屏幕”。
6. 在主屏幕打开 ADOCS，完成飞行模式下重启、修改航班、地图、甘特图和 Excel/JSON 导出的实机验收。

## 数据与安全

- 所有初始航班为 TEST 虚构数据，HOT 时间仅为演示；绝不能用于运行放行。
- 公开版使用内置测试示意图，不包含未经确认可公开发布的原始机位图。现场经授权的图纸可使用“更换底图”导入到**本机浏览器数据**中。
- 公网静态资源可被访问；无服务端登录和跨设备同步。IndexedDB 和 Service Worker 由浏览器管理，可能被系统清理，请导出 JSON 备份。
- 未验证 iPad Safari 真机断网重启和浏览器持久化，不能宣称生产级离线可靠性。
- 如果采用 `render.yaml` Blueprint 部署，将自动应用服务端响应头；使用普通 Render 静态站点创建时应在网站 Settings 中另行设置安全和缓存响应头（`render.yaml` 不一定被普通创建流程应用）。

开发来源：ADOCS v1.2，公开部署资源包 v1.2.1。项目不需要云数据库或运行时 API。
