/* ADOCS v1.2 PWA: install-time atomic app-shell cache. No external dependencies. */
'use strict';
const CACHE_NAME = 'adocs-shell-v1.2.1';
const CACHE_PREFIX = 'adocs-shell-';
const SHELL = [
 './','./index.html','./manifest.webmanifest','./offline-assets.json',
 './src/style.css','./src/domain.js','./src/chartStands.js',
 './src/demo.js','./src/store.js','./src/xlsx.js',
 './src/hotSafety.js','./src/app.js','./src/pwa.js',
 './assets/zytx-demo-schematic.svg','./assets/icon.svg',
 './assets/adocs-192.png','./assets/adocs-512.png',
 './assets/ADOCS_TEST_24_航班模板.xlsx'
];
self.addEventListener('install', event => {
 event.waitUntil((async () => {
  const cache = await caches.open(CACHE_NAME);
  // addAll is atomic for this cache: failing fetch prevents a misleading install.
  await cache.addAll(SHELL);
  await self.skipWaiting();
 })());
});
self.addEventListener('activate', event => {
 event.waitUntil((async () => {
  const names = await caches.keys();
  await Promise.all(names.filter(name=>(name.startsWith(CACHE_PREFIX)||name==='adocs-offline-v1')&&name!==CACHE_NAME).map(name=>caches.delete(name)));
  await self.clients.claim();
 })());
});
self.addEventListener('fetch', event => {
 if(event.request.method!=='GET')return;
 const url=new URL(event.request.url);
 if(url.origin!==self.location.origin)return;
 const scope=new URL(self.registration?.scope||'./',self.location.href);
 if(!url.pathname.startsWith(scope.pathname))return;
 event.respondWith((async () => {
  const cache=await caches.open(CACHE_NAME);
  if(event.request.mode==='navigate'){
   // Offline-first navigation works even if the original server is no longer reachable.
   const home=await cache.match(new URL('index.html',scope).href);
   if(home)return home;
  }
  const cached=await cache.match(event.request);
  if(cached)return cached;
  try{
   const response=await fetch(event.request);
   if(response.ok&&response.type==='basic')await cache.put(event.request,response.clone());
   return response;
  }catch(err){
   return new Response('ADOCS 未缓存此资源，请恢复连接后重新安装离线包。',{
    status:503,headers:{'Content-Type':'text/plain; charset=utf-8'}
   });
  }
 })());
});
self.addEventListener('message',event=>{
 if(event.data?.type==='ADOCS_CACHE_INFO'){
  event.waitUntil((async()=>{
   const cache=await caches.open(CACHE_NAME);
   const entries=await cache.keys();
   event.source?.postMessage({type:'ADOCS_CACHE_INFO',cache:CACHE_NAME,count:entries.length,expected:SHELL.length});
  })());
 }
});
