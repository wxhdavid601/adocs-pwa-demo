(function(root,factory){const api=factory(root.ADOCS|| (typeof require!=='undefined'?require('./domain.js'):{}),root.ADOCS|| (typeof require!=='undefined'?require('./chartStands.js'):{})); if(typeof module==='object'&&module.exports)module.exports=api;root.ADOCS=Object.assign(root.ADOCS||{},api);})(typeof window!=='undefined'?window:globalThis,function(D,M){
'use strict';
function demoState(){
 const date=D.cstNowDate(),f=[],stands=M.chartStands(),vehicles=[];
 const codes=['101','102','104','106','109','111','113','115','117','119','121','123','125','127','129','131','133','135','137','139','Y28','Y30','A01','M06'];
 for(let i=0;i<24;i++){
   const t=new Date(date+'T05:30:00+08:00').getTime()+i*37*60000;
   const std=new Date(t).toISOString(),etd=new Date(t+(i%5===0?25:0)*60000).toISOString();
   const stand=stands.find(s=>s.code===codes[i]);
   f.push(D.newFlight({date,flightNo:'TEST'+(5201+i),registration:'TEST-B'+(8000+i),aircraftType:['A320','A321','B737','A330'][i%4],inboundNo:'TEST'+(4101+i),std,etd,plannedArrival:new Date(t-120*60000).toISOString(),plannedStand:stand.code,zone:stand.zone,needsDeicing:i%6!==0,ownCompany:true,fixture:true,status:'计划'}));
 }
 for(let i=0;i<5;i++)vehicles.push({id:'veh-'+(i+1),code:'SIM-ICE-'+String(i+1).padStart(2,'0'),status:'可用',currentTaskId:null,availableAt:null,deviceType:'测试除冰车',issue:'',refilling:false});
 const current=D.now(),weather={id:'wx-demo',observedAt:D.addMin(current,-2),oat:-6,precipitation:'小雪',intensity:'轻',windSpeed:4,visibility:3000,source:'虚构演示气象',operator:'系统演示',verified:true,fixture:true};
 // Made-up durations are never operationally valid HOTs.
 const rule={id:'rule-demo',source:'人为编造的测试数字（不是 HOT 表）',version:'DEMO-ONLY-NOT-APPROVED',fluidProduct:'演示液 A',fluidType:'Type I',mixture:'100/0',method:'两步法',precipitation:'小雪',intensity:'轻',minOat:-15,maxOat:0,validFrom:'2020-01-01T00:00:00Z',validTo:'2099-12-31T23:59:59Z',lowerMin:10,upperMin:20,reviewer:'演示规则，未经运行批准',reviewedAt:current,approved:true,demo:true};
 return {meta:{schemaVersion:D.SCHEMA,revision:1,createdAt:current,savedAt:current,airport:'ZYTX',dataset:'SIMULATION',theme:'dark',reminderMin:5},flights:f,stands,tasks:[],weather:[weather],vehicles,hotRules:[rule],audits:[D.audit('INITIALIZE','SYSTEM','24 条虚构航班 + 机位图推定相对坐标，全部非运行数据')],map:{type:'schematic',dataUrl:null,name:'公开版内置测试示意图（非真实机场图）',version:'USER-CHART-1'}};
}
return {demoState};
});
