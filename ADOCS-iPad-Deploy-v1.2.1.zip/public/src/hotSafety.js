(function(root,factory){const api=factory(root.ADOCS|| (typeof require!=='undefined'?require('./domain.js'):{}));if(typeof module==='object'&&module.exports)module.exports=api;root.ADOCS=Object.assign(root.ADOCS||{},api);})(typeof window!=='undefined'?window:globalThis,function(D){
'use strict';
const disclaimer='保持时间为运行参考，不构成起飞放行许可；实际运行须遵守航空公司批准的程序及机组判断。';
function evaluate(task,weather,rules,nowMs=Date.now()){
 // This domain is isolated: no prediction, no weather inference, no generated HOT for missing rules.
 const result=D.hotResult(task,weather,rules,nowMs);
 if(result.kind==='unknown')return {...result,disclaimer};
 if(result.kind==='demo')return {...result,disclaimer,operational:false};
 return {...result,disclaimer,operational:false}; // advisory only, never takeoff clearance
}
function validateRule(r){
 const required=['id','source','version','fluidProduct','fluidType','mixture','method','precipitation','intensity','validFrom','validTo','reviewer','reviewedAt'];
 const miss=required.filter(k=>!r[k]);if(miss.length)throw new Error('HOT 规则缺少字段：'+miss.join('、'));
 if(!Number.isFinite(r.lowerMin)||!Number.isFinite(r.upperMin)||r.lowerMin<0||r.upperMin<r.lowerMin)throw new Error('HOT 数字无效');
 if(!Number.isFinite(r.minOat)||!Number.isFinite(r.maxOat)||r.maxOat<r.minOat)throw new Error('温度适用范围无效');
 if(!Number.isFinite(Date.parse(r.validFrom))||!Number.isFinite(Date.parse(r.validTo))||Date.parse(r.validTo)<Date.parse(r.validFrom))throw new Error('资料有效期无效');
 if(r.approved!==true)throw new Error('规则未严格标记人工批准，不允许导入为可用资料');
 if(r.demo)throw new Error('演示规则不得作为正式已批准数据导入');
 return {...r,approved:true,demo:false};
}
function latestWeather(state){return [...state.weather].sort((a,b)=>Date.parse(b.observedAt)-Date.parse(a.observedAt))[0];}
return {evaluate,validateRule,latestWeather,disclaimer};
});
