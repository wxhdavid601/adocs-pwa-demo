(function (root, factory) { const api = factory(); if(typeof module==='object' && module.exports) module.exports=api; root.ADOCS = Object.assign(root.ADOCS||{},api); })(typeof window!=='undefined'?window:globalThis, function(){
'use strict';
const TZ='Asia/Shanghai', SCHEMA=3;
const uuid=()=> (globalThis.crypto?.randomUUID?.() || 'id-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2));
const now=()=>new Date().toISOString();
const escapeHtml=(v)=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const atCst=(ms)=>new Date(ms+8*3600000);
function isoCst(v, date){
 if(v===undefined||v===null||v==='') return null;
 if(v instanceof Date) return isNaN(v)?null:v.toISOString();
 if(typeof v==='number') { const epoch=(v<1 && date ? new Date(date+'T00:00:00+08:00').getTime()+Math.round(v*86400000) : Date.UTC(1899,11,30)+Math.round(v*86400000)-8*3600000); return new Date(epoch).toISOString(); }
 let str=String(v).trim().replace(/\//g,'-');
 if(/^\d{1,2}:\d{2}(?::\d{2})?$/.test(str)) {if(!date)return null; str=date+'T'+str;}
 if(/^\d{4}-\d{1,2}-\d{1,2}$/.test(str)) str+='T00:00';
 str=str.replace(' ','T');
 if(/^\d{4}-\d{1,2}-\d{1,2}T\d{1,2}:\d{2}/.test(str) && !/(Z|[+-]\d{2}:?\d{2})$/i.test(str)) str+='+08:00';
 const d=new Date(str);return isNaN(d)?null:d.toISOString();
}
function dateCst(iso){if(!iso)return ''; const d=atCst(new Date(iso).getTime());return d.toISOString().slice(0,10);}
function fmt(iso, showDate=false){if(!iso)return '—';let d=new Date(iso);if(isNaN(d))return '—';return new Intl.DateTimeFormat('zh-CN',{timeZone:TZ,month:showDate?'2-digit':undefined,day:showDate?'2-digit':undefined,hour:'2-digit',minute:'2-digit',hour12:false}).format(d);}
function datetimeLocal(iso){if(!iso)return '';const d=atCst(new Date(iso).getTime());return d.toISOString().slice(0,16);}
function cstNowDate(){return dateCst(now());}
function addMin(iso,min){return new Date(new Date(iso).getTime()+min*60000).toISOString();}
const depart=(f)=>f.etd||f.std;
function sortedFlights(fs){return [...fs].sort((a,b)=>new Date(depart(a)||0)-new Date(depart(b)||0));}
function flightWindow(f){const end=depart(f);if(!end)return null;return {start:new Date(end).getTime()-90*60000,end:new Date(end).getTime()+15*60000};}
function overlap(a,b){return Boolean(a&&b&&a.start<b.end&&b.start<a.end);}
function standConflicts(flights){const found=[];for(let i=0;i<flights.length;i++)for(let j=i+1;j<flights.length;j++){let a=flights[i],b=flights[j];if(a.status==='已取消'||b.status==='已取消')continue;const sa=a.actualStand||a.plannedStand,sb=b.actualStand||b.plannedStand;if(sa&&sa===sb&&overlap(flightWindow(a),flightWindow(b)))found.push({kind:'stand',resource:sa,flightIds:[a.id,b.id],message:`机位 ${sa}：${a.flightNo} / ${b.flightNo} 时间窗重叠（按 ETD 前90分至后15分的预警模型）`});}return found;}
function vehicleConflicts(tasks){const found=[];for(let i=0;i<tasks.length;i++)for(let j=i+1;j<tasks.length;j++){let a=tasks[i],b=tasks[j];if(!a.vehicleId||a.vehicleId!==b.vehicleId||!a.startedAt||!b.startedAt)continue;const endA=a.endedAt?new Date(a.endedAt).getTime():Date.now(),endB=b.endedAt?new Date(b.endedAt).getTime():Date.now();if(overlap({start:new Date(a.startedAt).getTime(),end:endA},{start:new Date(b.startedAt).getTime(),end:endB}))found.push({kind:'vehicle',resource:a.vehicleId,flightIds:[a.flightId,b.flightId],message:`车辆 ${a.vehicleId}：两项实际作业时间重叠`});}return found;}
function hotResult(task, weather, rules, nowMs=Date.now()) {
 const fail=(reason)=>({kind:'unknown',reason,message:'无法确定 HOT，请人工复核'});
 if(!task?.hotStartAt)return fail('尚未记录最后一步施液开始时间');
 if(!task.fluidProduct||!task.fluidType||!task.method||!task.mixture)return fail('液体/方法/配比资料不完整');
 if(!weather||!weather.verified)return fail('缺少已人工核实的气象记录');
 if(typeof weather.oat!=='number'||!weather.precipitation||!weather.intensity)return fail('气象条件不完整');
 if(task.weatherId&&task.weatherId!==weather.id)return fail('气象条件已更新，需重新人工复核');
 const latest=new Date(weather.observedAt).getTime(),started=new Date(task.hotStartAt).getTime();
 if(latest>started)return fail('起算后的新气象观测须人工重新评估');
 const candidates=rules.filter(r=>r.approved&&r.method===task.method&&r.fluidProduct===task.fluidProduct&&r.fluidType===task.fluidType&&r.mixture===task.mixture&&r.precipitation===weather.precipitation&&r.intensity===weather.intensity&&weather.oat>=r.minOat&&weather.oat<=r.maxOat&&r.lowerMin>=0&&r.upperMin>=r.lowerMin&&new Date(r.validFrom)<=new Date(task.hotStartAt)&&new Date(r.validTo)>=new Date(task.hotStartAt)&&Boolean(r.reviewer)&&Boolean(r.version));
 if(!candidates.length)return fail('无匹配且已批准的适用规则');
 // Demo entries are deliberately never considered operationally approved.
 const rule=candidates.find(r=>!r.demo)||candidates[0], kind=rule.demo?'demo':'reference';
 const lower=addMin(task.hotStartAt,rule.lowerMin), upper=addMin(task.hotStartAt,rule.upperMin);
 return {kind,rule,lower,upper,remainingLowerMs:new Date(lower).getTime()-nowMs,remainingUpperMs:new Date(upper).getTime()-nowMs,message:kind==='demo'?'演示参考 · 严禁用于真实运行':'已匹配人工核对规则 · 仍非放行许可'};
}
function newFlight(data){const t=now();return {id:uuid(),date:data.date||cstNowDate(),flightNo:data.flightNo||'',registration:data.registration||'',aircraftType:data.aircraftType||'',inboundNo:data.inboundNo||'',plannedArrival:data.plannedArrival||null,actualArrival:data.actualArrival||null,std:data.std||null,etd:data.etd||null,atd:data.atd||null,plannedStand:data.plannedStand||'',actualStand:data.actualStand||'',zone:data.zone||'',status:data.status||'计划',needsDeicing:data.needsDeicing!==false,taskId:data.taskId||null,ownCompany:data.ownCompany!==false,manualOverrides:data.manualOverrides||{},updatedAt:t,updatedBy:'导入',version:1,fixture:!!data.fixture};}
function importRows(existing, rows, mapping){
 const accepted=[],errors=[],warnings=[],updates=[],seen=new Set();let inserted=0,updated=0;
 const fields=['date','flightNo','registration','aircraftType','inboundNo','plannedArrival','actualArrival','std','etd','atd','plannedStand','actualStand','zone','status','needsDeicing'];
 rows.forEach((row,i)=>{
  const raw={};for(const key of fields)if(mapping[key]!==undefined && mapping[key]!=='' && row[mapping[key]]!==undefined)raw[key]=row[mapping[key]];
  const dateRaw=String(raw.date??'').trim();let date=dateRaw;
  if(typeof raw.date==='number')date=dateCst(isoCst(raw.date));
  if(/^\d{4}[-/]\d{1,2}[-/]\d{1,2}/.test(date))date=date.replaceAll('/','-').slice(0,10);
  const flightNo=String(raw.flightNo??'').trim().toUpperCase();
  const std=isoCst(raw.std,date);if(!date||!/^\d{4}-\d{2}-\d{2}$/.test(date)||!flightNo||!std){errors.push({row:i+2,message:`缺少或无效的日期/航班号/STD（${flightNo||'空'}）`});return;}
  const key=date+'|'+flightNo;if(seen.has(key)){errors.push({row:i+2,message:`本次文件内重复航班 ${key}`});return;}seen.add(key);
  let etd=isoCst(raw.etd,date),arr=isoCst(raw.plannedArrival,date);
  if(etd&&new Date(etd)<new Date(std)&&new Date(std)-new Date(etd)>6*3600000)etd=addMin(etd,1440);
  if(arr&&new Date(arr)>new Date(std)&&new Date(arr)-new Date(std)>6*3600000)arr=addMin(arr,-1440);
  const actualArrival=isoCst(raw.actualArrival,date),atd=isoCst(raw.atd,date);
  const obj={date,flightNo,registration:String(raw.registration||''),aircraftType:String(raw.aircraftType||''),inboundNo:String(raw.inboundNo||''),plannedArrival:arr,actualArrival,std,etd,atd,plannedStand:String(raw.plannedStand||''),actualStand:String(raw.actualStand||''),zone:String(raw.zone||''),status:String(raw.status||'计划'),needsDeicing:!['否','N','NO','FALSE','0'].includes(String(raw.needsDeicing??'是').toUpperCase())};
  for(const f of ['etd','plannedArrival','actualArrival','atd'])if(raw[f] && !obj[f])errors.push({row:i+2,message:`${f} 无法解析，不允许静默忽略`});
  if(errors.some(e=>e.row===i+2))return;
  const old=existing.find(x=>x.date===date&&x.flightNo===flightNo);
  if(old){const patch={};Object.keys(obj).forEach(field=>{if(['date','flightNo'].includes(field))return;if(old.manualOverrides?.[field] || (['actualArrival','atd','actualStand'].includes(field)&&old[field])){if(obj[field]&&old[field]!==obj[field])warnings.push({row:i+2,message:`${flightNo} ${field} 已有现场/人工记录，导入不覆盖`});return;}if((obj[field]!==null&&obj[field]!=='')&&obj[field]!==old[field])patch[field]=obj[field];});if(Object.keys(patch).length){updates.push({id:old.id,patch});updated++;}}
  else {accepted.push(newFlight(obj));inserted++;}
 });
 return {accepted,updates,errors,warnings,inserted,updated};
}
function applyImportState(state,plan){for(const f of plan.accepted)state.flights.push(f);for(const u of plan.updates){const f=state.flights.find(f=>f.id===u.id);if(f){Object.assign(f,u.patch);f.updatedAt=now();f.updatedBy='Excel 导入';f.version++;}}return state;}
function statusOf(f,t){if(f.status==='已取消')return '已取消';if(t?.endedAt)return '已完成';if(t?.startedAt)return '作业中';return f.needsDeicing?'待除冰':'无需除冰';}
function audit(action,entityId,detail,operator='本机操作员'){return {id:uuid(),at:now(),action,entityId,detail,operator};}
return {SCHEMA,TZ,uuid,now,escapeHtml,isoCst,dateCst,fmt,datetimeLocal,cstNowDate,addMin,depart,sortedFlights,flightWindow,overlap,standConflicts,vehicleConflicts,hotResult,newFlight,importRows,applyImportState,statusOf,audit};
});
