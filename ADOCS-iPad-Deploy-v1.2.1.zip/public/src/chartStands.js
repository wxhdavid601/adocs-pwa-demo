(function(root,factory){const api=factory(root.ADOCS||{});if(typeof module==='object'&&module.exports)module.exports=api;root.ADOCS=Object.assign(root.ADOCS||{},api);})(typeof window!=='undefined'?window:globalThis,function(D){
'use strict';
// Approximate *diagram-space* coordinates, manually interpolated from a user-provided low-resolution
// ZYTX parking chart. These are NOT surveyed coordinates nor an authoritative stand inventory.
// Counts below come from the readable stand identifiers in the supplied chart legend.
const pts=[];
const add=(code,zone,x,y)=>pts.push({id:'stand-'+code,airport:'ZYTX',code,zone,x:Math.max(.02,Math.min(.98,x)),y:Math.max(.04,Math.min(.96,y)),labelDx:0,labelDy:-12,status:'图纸推定（未现场校准）',restrictions:'图纸相对布局，未经现场校准；仅供非运行演示',mapVersion:'USER-CHART-1',calibration:'approximate'});
const line=(codes,zone,x1,y1,x2,y2)=>codes.forEach((code,i)=>{let t=codes.length===1?.5:i/(codes.length-1);add(code,zone,x1+(x2-x1)*t,y1+(y2-y1)*t);});
// Terminal-facing stands and the long parallel apron strip, from southwest toward northeast.
line(Array.from({length:14},(_,i)=>String(101+i)),'T2 主机坪',.20,.68,.70,.33);
line(Array.from({length:13},(_,i)=>String(115+i)),'T2 主机坪',.22,.64,.74,.29);
// Southern curved T3 apron, approximate from the location and direction of T3 in the chart.
line(Array.from({length:13},(_,i)=>String(128+i)),'T3 主机坪',.30,.69,.71,.89);
line(['Y21','Y03','Y04','Y06','Y07','Y08','Y09','Y10'],'远机位/补充',.17,.60,.69,.96);
line(Array.from({length:10},(_,i)=>'Y'+String(11+i)+'R'),'远机位/补充',.43,.51,.79,.22);
line(Array.from({length:7},(_,i)=>'Y'+String(28+i)),'北部远机位',.76,.26,.96,.07);
line(['M2','M3','M4','M5'],'南部机坪',.78,.83,.85,.88);
line(['A01','A02','A03','A04'],'南部机坪',.20,.84,.47,.93);
line(['M06','M07','M07L','M07R','M08','M08L','M08R'],'南部机坪',.46,.72,.65,.88);
line(['G1','G2','G3','G4'],'通航/附属',.13,.92,.34,.95);
const knownCodes=pts.map(p=>p.code);
function chartStands(){return pts.map(s=>({...s}));}
return {chartStands,knownCodes};
});
