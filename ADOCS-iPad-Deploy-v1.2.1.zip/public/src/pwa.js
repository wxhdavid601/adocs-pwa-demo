/* ADOCS v1.2: trusted-HTTPS install assistant, integrity-checked offline shell, IndexedDB probe.
   No network API, telemetry, user data upload or backend authentication. */
(function(){'use strict';
 const statusEl=document.getElementById('pwaStatus');
 const panel=document.getElementById('pwaPanel');
 const steps=document.getElementById('pwaSteps');
 const detail=document.getElementById('pwaDetail');
 const guide=document.getElementById('pwaGuide');
 const installBtn=document.getElementById('pwaInstall');
 const persistBtn=document.getElementById('pwaPersist');
 const guideBtn=document.getElementById('pwaGuideOpen');
 const CACHE='adocs-shell-v1.2.1';
 const VERSION='1.2.1';
 const manifestUrl=document.querySelector('link[rel="manifest"]')?.href||new URL('./manifest.webmanifest',location.href).href;
 const BASE=(()=>{try{return new URL('./',manifestUrl).href;}catch{return location.href;}})(); // works at /project-name/; non-HTTP test documents cannot register
 const isiPad=/iPad/.test(navigator.userAgent) || (/Macintosh/.test(navigator.userAgent)&&navigator.maxTouchPoints>1);
 const standalone=()=>window.matchMedia('(display-mode: standalone)').matches||navigator.standalone===true;
 const secure=()=>window.isSecureContext && (location.protocol==='https:'||['localhost','127.0.0.1'].includes(location.hostname));
 let deferredInstall=null,checkInFlight=null;
 let lastCheck={ready:false,controlled:false,cached:false,storage:'未检查',offline:false,error:'',verified:0,total:0};
 function addStep(index,title,description,complete){
  const div=document.createElement('div');div.className='pwa-step '+(complete?'completed':'pending');
  const circle=document.createElement('span');circle.className='step-number';circle.textContent=complete?'✓':String(index);
  const info=document.createElement('span');const strong=document.createElement('strong');strong.textContent=title;
  const small=document.createElement('small');small.textContent=description;info.append(strong,small);div.append(circle,info);steps.appendChild(div);
 }
 function showCheck(r){
  lastCheck=r;
  statusEl.textContent=r.ready?'✓ 离线已就绪':!secure()?'⚠ 需要 HTTPS':r.error?'⚠ 离线未就绪':'◌ 准备离线资源';
  statusEl.dataset.ready=String(r.ready);
  statusEl.title=r.ready?'全部必需资源和本地数据库已通过校验；仍需实际断网重启验收':'点击检查安装及离线状态';
  steps.replaceChildren();
  addStep(1,'打开安全网址',secure()?'当前网页为安全来源':'必须使用可信 HTTPS；iPad 无需手动信任自签证书',secure());
  addStep(2,'准备完整离线资源',r.cached?`已验证 ${r.verified}/${r.total} 个静态资源的 SHA-256 摘要`:`缓存验证进度：${r.verified}/${r.total}，点击“检验离线资源与本地存储”`,r.cached);
  addStep(3,standalone()?'已从主屏幕运行':'添加到主屏幕',standalone()?'当前以独立 App 模式启动':isiPad?'iPad Safari：分享 → 添加到主屏幕 → 打开为网页 App':'Mac：Chrome/Edge 点击安装；Safari 选择添加到程序坞',standalone());
  addStep(4,'实际断网重启验收','在已安装的 App 内确认“离线已就绪”，开启飞行模式并关闭 Wi-Fi，完全退出后重新打开，验证航班记录与导出。',false);
  detail.replaceChildren();
  const texts=[
   r.ready?'✓ 本设备完整离线包与本地存储检查通过（不等于已通过真机断网重启验收）':'⚠ 本设备尚未确认离线可用',
   r.offline?'网络状态：浏览器报告断网':'网络状态：浏览器报告有网络（不等于能够连接互联网）',
   r.controlled?'离线程序：已控制当前页面':'离线程序：尚未控制当前页面',
   `缓存资源：${r.verified}/${r.total} 项完成校验`,
   '本地存储：'+r.storage
  ];
  if(r.error)texts.push('待处理：'+r.error);
  const ul=document.createElement('ul');ul.className='pwa-checklist';
  for(const line of texts){const li=document.createElement('li');li.textContent=line;ul.appendChild(li);}
  detail.appendChild(ul);
  guide.textContent=isiPad?'iPad 首次：Safari 打开 HTTPS 地址，等待“离线已就绪”，分享 → 添加到主屏幕 → 开启“作为网页 App 打开”。在主屏幕 App 内再次检查，再切断 Wi-Fi 做完整重启测试。':'Mac：Chrome/Edge 使用安装应用菜单；Safari 选择“文件 → 添加到程序坞”。首次安装时需要网络，缓存完成后可独立离线使用。';
  installBtn.hidden=!deferredInstall;
 }
 async function verifyCache(){
  const result={cached:false,verified:0,total:0,reason:''};
  const names=await caches.keys();
  if(!names.includes(CACHE)){result.reason='尚未安装当前 v1.2 离线缓存，首次需要联网访问并等待缓存完成。';return result;}
  const cache=await caches.open(CACHE);
  const manifestResponse=await cache.match(new URL('./offline-assets.json',BASE).href);
  if(!manifestResponse){result.reason='缺少离线校验清单；请保持联网重新加载页面。';return result;}
  const m=await manifestResponse.json();
  if(m.version!==VERSION||!Array.isArray(m.assets)||m.assets.length<15){result.reason='离线资源清单版本或格式不匹配';return result;}
  result.total=m.assets.length;
  if(!globalThis.crypto?.subtle){result.reason='浏览器未提供安全哈希校验功能，无法证明离线资源完整';return result;}
  for(const asset of m.assets){
   if(!asset.url?.startsWith('./')||!Number.isSafeInteger(asset.bytes)||!(/^[a-f0-9]{64}$/.test(asset.sha256))){result.reason='离线资源清单存在无效项目';return result;}
   const response=await cache.match(new URL(asset.url,BASE).href);
   if(!response||!response.ok){result.reason='缺少必需离线文件：'+asset.url;return result;}
   const bytes=await response.arrayBuffer();
   if(bytes.byteLength!==asset.bytes){result.reason='离线文件大小不符：'+asset.url;return result;}
   const hash=await crypto.subtle.digest('SHA-256',bytes);
   const hex=Array.from(new Uint8Array(hash),b=>b.toString(16).padStart(2,'0')).join('');
   if(hex!==asset.sha256){result.reason='离线文件校验失败：'+asset.url;return result;}
   result.verified++;
  }
  result.cached=true;return result;
 }
 function testIndexedDb(){
  return new Promise((resolve,reject)=>{
   if(!globalThis.indexedDB){reject(Error('不支持 IndexedDB'));return;}
   const name='ADOCS_PWA_Storage_Probe';
   let open;
   try{open=indexedDB.open(name,1);}catch(err){reject(err);return;}
   open.onupgradeneeded=()=>{if(!open.result.objectStoreNames.contains('items'))open.result.createObjectStore('items');};
   open.onerror=()=>reject(open.error||Error('打开本地数据库失败'));
   open.onsuccess=()=>{
    const db=open.result;const marker='ADOCS-'+Date.now();
    try{
     const tx=db.transaction('items','readwrite');const store=tx.objectStore('items');
     store.put(marker,'check');
     const got=store.get('check');
     got.onsuccess=()=>{if(got.result!==marker){tx.abort();reject(Error('本地数据库读写结果不一致'));}};
     tx.oncomplete=()=>{db.close();resolve(true);};
     tx.onerror=()=>{db.close();reject(tx.error||Error('数据库事务失败'));};
     tx.onabort=()=>{db.close();reject(tx.error||Error('数据库事务中止'));};
    }catch(err){db.close();reject(err);}
   };
  });
 }
 async function check(){
  if(checkInFlight)return checkInFlight;
  checkInFlight=(async()=>{
   const r={ready:false,controlled:!!navigator.serviceWorker?.controller,cached:false,storage:'未检查',offline:navigator.onLine===false,error:'',verified:0,total:0};
   try{
    if(!secure())r.error='当前网址不是安全来源，请使用提供商正式 HTTPS 地址。';
    else if(!('serviceWorker' in navigator))r.error='当前浏览器不支持 Service Worker。';
    else{
     const c=await verifyCache();
     Object.assign(r,{cached:c.cached,verified:c.verified,total:c.total});
     if(!r.cached)r.error=c.reason;
    }
    try{
     await testIndexedDb();
     r.storage='IndexedDB 写入并读取测试通过';
     if(navigator.storage?.persisted){
      const p=await navigator.storage.persisted();
      r.storage+=p?'；持久存储已获允许':'；未获持久存储承诺，须定期备份';
     }
    }catch(error){r.storage='不能写入或读取：'+String(error.message||error);r.error=r.error||'本地数据库不可用';}
    r.ready=secure()&&r.controlled&&r.cached&&r.storage.startsWith('IndexedDB 写入并读取测试通过');
   }catch(error){r.error='状态检查出错：'+String(error.message||error);}
   showCheck(r);return r;
  })().finally(()=>{checkInFlight=null;});
  return checkInFlight;
 }
 function setPanel(open){panel.hidden=!open;statusEl.setAttribute('aria-expanded',String(open));if(open)check();}
 statusEl.addEventListener('click',()=>setPanel(panel.hidden));
 guideBtn?.addEventListener('click',()=>setPanel(true));
 document.getElementById('pwaClose').addEventListener('click',()=>setPanel(false));
 document.getElementById('pwaCheck').addEventListener('click',check);
 persistBtn.addEventListener('click',async()=>{
  try{
   if(!navigator.storage?.persist){alert('此浏览器不支持请求持久存储。请定期导出 JSON。');return;}
   const granted=await navigator.storage.persist();
   alert(granted?'浏览器已授予持久存储；仍需按期备份。':'浏览器未授予持久存储；请定期备份。');
   await check();
  }catch(error){alert('请求持久存储失败：'+error.message);}
 });
 window.addEventListener('beforeinstallprompt',ev=>{ev.preventDefault();deferredInstall=ev;installBtn.hidden=false;});
 installBtn.addEventListener('click',async()=>{
  if(!deferredInstall)return;
  const ev=deferredInstall;deferredInstall=null;installBtn.hidden=true;await ev.prompt();
 });
 window.addEventListener('appinstalled',()=>{deferredInstall=null;installBtn.hidden=true;check();});
 window.addEventListener('online',check);
 window.addEventListener('offline',check);
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)check();});
 if('serviceWorker' in navigator){
  navigator.serviceWorker.addEventListener('controllerchange',check);
  if(secure()){
   navigator.serviceWorker.register(new URL('sw.js',BASE).href,{scope:BASE,updateViaCache:'none'})
    .then(async reg=>{
     await navigator.serviceWorker.ready;await check();
     reg.addEventListener('updatefound',()=>{
      const worker=reg.installing;
      worker?.addEventListener('statechange',()=>{if(worker.state==='activated')check();});
     });
    }).catch(error=>showCheck({...lastCheck,error:'离线程序安装失败：'+error.message}));
  }
 }
 showCheck(lastCheck);
 setTimeout(check,500);
 if(isiPad&&!standalone()){
  // Offer install instructions once per Safari tab session; never block the app.
  try{if(!sessionStorage.getItem('ADOCS_V12_GUIDED')){sessionStorage.setItem('ADOCS_V12_GUIDED','1');setTimeout(()=>setPanel(true),1100);}}catch{}
 }
 window.ADOCS_PWA={check,getStatus:()=>({...lastCheck}),cacheName:CACHE,base:BASE};
})();
