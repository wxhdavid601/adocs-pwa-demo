(function(root,factory){const api=factory(root.ADOCS||{});if(typeof module==='object'&&module.exports)module.exports=api;root.ADOCS=Object.assign(root.ADOCS||{},api);})(typeof window!=='undefined'?window:globalThis,function(D){
'use strict';
const DB='ADOCS_Offline_v3',KEY='authoritative';
function openDb(){return new Promise((resolve,reject)=>{if(!globalThis.indexedDB)return reject(new Error('浏览器不支持 IndexedDB，无法可靠持久化'));const r=indexedDB.open(DB,3);r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains('records'))r.result.createObjectStore('records');};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});}
function transaction(db,mode,action){return new Promise((resolve,reject)=>{const tx=db.transaction('records',mode);let req=action(tx.objectStore('records'));tx.oncomplete=()=>resolve(req?.result);tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||new Error('事务已中止'));});}
class Store{
 constructor(){this.db=null;this.state=null;this.listeners=[];this.writeQueue=Promise.resolve();}
 async init(){this.db=await openDb();let saved=await transaction(this.db,'readonly',s=>s.get(KEY));if(!saved){saved=D.demoState();await transaction(this.db,'readwrite',s=>s.put(saved,KEY));}if(saved?.meta?.schemaVersion>D.SCHEMA)throw new Error('数据库版本高于程序，禁止使用旧程序覆盖');if(saved?.meta?.schemaVersion<D.SCHEMA){saved=this.migrate(saved);await transaction(this.db,'readwrite',s=>s.put(saved,KEY));}this.state=saved;this.emit();return this.state;}
 migrate(st){st.meta.schemaVersion=D.SCHEMA;st.meta.revision=(st.meta.revision||0)+1;st.audits=st.audits||[];st.hotRules=st.hotRules||[];st.weather=st.weather||[];st.map=st.map||{type:'placeholder',version:'DEMO-1'};st.audits.push(D.audit('MIGRATION','SYSTEM','升级本地数据结构到 v'+D.SCHEMA));return st;}
 subscribe(cb){this.listeners.push(cb);return ()=>this.listeners=this.listeners.filter(x=>x!==cb);}
 emit(){for(const l of this.listeners)l(this.state);}
 // Serialized IndexedDB readwrite transaction; the browser database is the local authority.
 async mutate(action,fn,entityId='SYSTEM',operator='本机操作员'){
  const run=async()=>{const next=structuredClone(this.state);const result=await fn(next);next.meta.savedAt=D.now();next.meta.revision++;next.audits.push(D.audit(action,entityId,JSON.stringify(result??{}).slice(0,2500),operator));await transaction(this.db,'readwrite',s=>s.put(next,KEY));this.state=next;this.emit();return result;};
  this.writeQueue=this.writeQueue.catch(()=>{}).then(run);return this.writeQueue;
 }
 async restore(backup,override=false){
  if(!backup?.meta||!Array.isArray(backup.flights)||!Array.isArray(backup.stands))throw new Error('备份包无效');
  if(backup.meta.schemaVersion!==D.SCHEMA)throw new Error('备份数据结构版本不匹配，请使用匹配版本转换');
  if(!override && backup.meta.revision<this.state.meta.revision)throw new Error('备份版本早于现有数据，已拒绝覆盖');
  const next=structuredClone(backup);next.meta.revision=Math.max(next.meta.revision,this.state.meta.revision)+1;next.meta.savedAt=D.now();next.audits=next.audits||[];next.audits.push(D.audit('RESTORE','SYSTEM','导入完整备份，原数据库版本 '+this.state.meta.revision));
  await transaction(this.db,'readwrite',s=>s.put(next,KEY));this.state=next;this.emit();
 }
}
return {Store,openDb};
});
